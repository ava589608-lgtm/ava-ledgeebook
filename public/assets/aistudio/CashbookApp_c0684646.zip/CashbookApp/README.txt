Cashbook Android app - build steps
1. Install Android Studio (free).
2. Open this folder (CashbookApp) in Android Studio and wait for Gradle sync.
3. Open app/src/main/java/com/cashbook/app/MainActivity.java and paste your web app URL.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Click "locate" to find app-debug.apk, send it to your phone and install it.
The app opens Cashbook in Chrome, so Google sign-in, camera and file upload work normally.
