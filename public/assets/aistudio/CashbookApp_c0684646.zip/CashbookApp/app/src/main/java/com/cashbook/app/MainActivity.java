package com.cashbook.app;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import androidx.browser.customtabs.CustomTabsIntent;

public class MainActivity extends Activity {
    // 1. Paste your Apps Script web app URL here (it ends with /exec).
    // 2. Keep ?v=pro for the Pro app, or remove it for the Basic app.
    static final String URL = "https://script.google.com/macros/s/YOUR_DEPLOYMENT_ID/exec?v=pro";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        CustomTabsIntent tab = new CustomTabsIntent.Builder()
                .setToolbarColor(0xFF1B2A28)
                .setShowTitle(true)
                .build();
        tab.intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        tab.launchUrl(this, Uri.parse(URL));
        finish();
    }
}
